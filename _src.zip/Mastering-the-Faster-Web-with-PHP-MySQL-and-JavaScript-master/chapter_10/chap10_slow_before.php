<?php

// chap10_slow_before.php

sleep(5);

echo 'The original page loads very slowly...';