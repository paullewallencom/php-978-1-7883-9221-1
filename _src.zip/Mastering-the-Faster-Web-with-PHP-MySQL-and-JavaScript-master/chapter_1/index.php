<?php

phpinfo();

$test = 'This is a test!';

$test1 = $test;

echo $test1;
